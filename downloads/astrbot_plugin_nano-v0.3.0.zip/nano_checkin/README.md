# Nano 多账号签到 · AstrBot 内置视图

GitHub 直接安装 / 更新地址：

```text
https://github.com/LiChenguang6/vpn-signs
```

**v0.3.0 使用 AstrBot 插件详情中的“视图”管理账号。** 登录 AstrBot 后即可进入，不再启动独立网页服务，不需要 `6198` 端口、反向代理或额外管理密码。

## 安装或从旧版升级

1. 使用 **AstrBot 4.29.3+、Python 3.12+**。在「插件 → 通过链接安装」输入上述 GitHub 地址，或更新已安装的 Nano 插件。
2. 本次更新后重载一次以加载新版代码和发现视图。以后配置字段填错，只需在视图里改正保存，不需要删除插件或重新加载。
3. 打开 **插件 → Nano 多账号签到 → 视图 → Nano 签到管理**。部分 AstrBot 版本也可从侧栏的插件视图入口进入。
4. 如果旧版已加载失败，可以用同一仓库链接覆盖安装新版。保留原有 AstrBot `data/config` 和 `data/plugin_data` 数据，不要通过删除账号配置来解决加载问题。

仓库根目录包含 `main.py`、`metadata.yaml`、`_conf_schema.json` 和依赖；视图入口为 `views/nano/index.html`，使用官方 `AstrBotPluginView` bridge 和 Dashboard Web API。

## 配置出错如何恢复

- 错误的时间、时区、API、群会话或账号字段不会阻止插件加载，任务会暂停，视图显示错误提示。
- 直接在视图修正并点击「保存全部配置」。保存成功后同一个插件实例恢复工作。
- 视图提交的新配置若不合规，会明确报错，保留表单和上次已保存配置，不会让插件退出。
- 修复已存在的错误配置前，原配置备份到 `data/plugin_data/nano_checkin/config-recovery-*.json`，权限为 `0600`。格式损坏的字段会在编辑页面中以安全默认值显示，保存前请核对账号和目标群列表。
- 已保存密码不会返回浏览器；同一账号的密码留空时保留原值。更换邮箱或 API 地址时要重新输入密码，避免把旧密码提交给另一个服务。

上述恢复针对插件配置字段及其格式。手工编辑底层 JSON 导致文件无法被 AstrBot 自身解析、磁盘不可写等框架/存储问题，仍需要修复对应文件或权限，不应删除账号数据。

## 多账号、每日签到和群推送

1. 在视图中核对默认 Nano API 根地址（包含 `/api/v1`）。预填地址来自用户上传的 Nano 1.0.10 样本公共配置：`https://account.alibaba.alicdn.men/api/v1`。它是第三方地址，可能变化，请确认仍为自己的 Nano 服务；不是订阅链接，也不代表 Alibaba 官方服务。
2. 点击「添加账号」，填写备注、邮箱/账号和密码，可添加多个账号。每个账号可独立启用、覆盖 API 地址及指定群会话。
3. 保存后先点击「测试登录」，再用「立即签到」核验。无需自己获取登录令牌，也不需要设置账号环境变量。
4. 用 **AstrBot 管理员账号**在目标 QQ 群发送 `/nano绑定群`，即可加入全局推送列表；可绑定多个群。也可用 `/nano会话` 获取完整会话标识后填到视图中，不能只填写 QQ 群号。
5. 账号专属推送会话非空时覆盖全局会话，留空则继承全局列表。
6. 设置每日时间和时区，验证后开启自动签到。默认 `08:00`、`Asia/Singapore`（UTC+8）。手动签到不要求打开全局自动开关，但会跳过单独禁用的账号。

每个账号独立登录、防重和重试；一个账号失败后会继续处理其他账号。每日每账号最多尝试 3 次，自动重试间隔 15 分钟。同一目标的本次结果合并推送；发送失败或超时会持久化重试，不会因推送失败重复签到。任务总开关关闭时自动重试也暂停。

| 管理员指令 | 功能 |
| --- | --- |
| `/nano签到` | 手动执行全部启用账号 |
| `/nano状态` | 查看账号完成情况与待推送数量 |
| `/nano会话` | 获取当前完整会话标识 |
| `/nano绑定群` | 当前群加入全局推送列表 |
| `/nano解绑群` | 从全局列表移除当前会话；账号专属目标请在视图修改 |
| `/nano测试推送` | 向已配置目标发送测试消息，不执行签到 |

常见 OneBot/NapCat QQ 适配器可主动推送。AstrBot QQ 官方 API 适配器不支持这里使用的 `Context.send_message`，不保证适用；机器人须已加入目标群且可以发言。

## 群晖运行与数据保护

使用现有 AstrBot 容器和 QQ 适配器，持久化挂载 AstrBot 的 `data` 目录，并设置容器重启策略。内置视图直接使用 AstrBot 登录鉴权，无需增加端口映射；旧版独立面板端口设置已不再使用。

账号密码保存在本地 `data/config/nano_checkin_config.json`。密码字段默认遮蔽显示，**遮蔽不等于加密**。加载及视图保存时设置文件权限为 `0600`；保护 NAS 管理权限、AstrBot HTTPS 入口、配置和修复备份，不要上传真实配置或把密码发到聊天。

状态保存在 `data/plugin_data/nano_checkin/state.json`，不保存邮箱、密码或登录令牌。令牌仅在本次登录签到的内存中使用，不回传视图或群消息。同一数据目录只运行一个 AstrBot 实例。

## 支持范围与验证

接口采用 Nano 样本出现的 V2Board 风格路径：表单 `POST /passport/auth/login` 提交 `email`、`password`，读取 `data.auth_data`；查询 `GET /user/checkinStatus` 的布尔字段 `data.can_checkin`，允许时 `POST /user/checkin`。服务可能存在定制或额外验证，不是通用的所有 VPN 服务签到插件。

账号请求保持 HTTPS、证书验证且不跟随重定向，不绕过验证码、2FA、设备签名或服务限制。未知响应不会仅凭 HTTP 200 判定成功。

测试包括配置错误恢复、实际 AstrBot 插件管理器加载和视图发现、官方后端请求路由，以及真实 Chromium 的沙箱 iframe + 官方 bridge SDK 操作。测试使用本地虚拟账号；**尚未用用户真实 Nano 账号和 QQ 群端到端验证**，首次请核对原客户端签到奖励和群消息。

[版本记录](CHANGELOG.md) · [v0.3.0 视图集成测试截图](docs/Nano-view-v0.3.0.png) · [早期 APK 静态分析](docs/Nano-APK-analysis.md)

## 开发检查

```sh
python3 -m pip install -r requirements.txt
python3 -m unittest discover -s tests -v
```

已安装 AstrBot SDK 的环境还可执行：

```sh
python3 tests/sdk_smoke.py
python3 tests/install_smoke.py
python3 tests/install_smoke.py --remote
```

浏览器集成测试需 Playwright、Chromium、AstrBot SDK 和 uvicorn：`python3 tests/browser_smoke.py`。截图为本地测试宿主中的沙箱视图，包含模拟数据。
